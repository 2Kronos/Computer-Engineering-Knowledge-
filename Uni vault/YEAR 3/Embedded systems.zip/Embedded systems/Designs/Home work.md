# Read input from the potentiometer and print it to the serial monitor 

- Design found at
  https://www.tinkercad.com/things/cqTXNAewx44-homework?sharecode=WUXBK5s2KlP7xF5I5mEbpJPtpQQP-NVox2cijQtSHxA