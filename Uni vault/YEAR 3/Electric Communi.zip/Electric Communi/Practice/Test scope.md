26-03-2025
17:00
Gencore 1,2,3,4

3 questions with sub-questions
Formula sheet

- Questionon on the important about measuring DBM
- When must you determine the gain why is it important 
- DB Dbm calculation
- Deriving the gain formulas 
- 