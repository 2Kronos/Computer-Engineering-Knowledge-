
1. **Introduction** – The global population is rapidly increasing, while the agricultural workforce is shrinking and aging, leading to potential food shortages. Mechanization helps reduce labor needs, but fruit farming remains heavily reliant on manual work due to challenges in automation. This research focuses on developing a gesture-controlled robotic arm for efficient fruit harvesting.
    
2. **Challenges in Fruit Production Automation** – Despite mechanization advances in grain farming, fruit production still requires intensive manual labor (e.g., harvesting, pruning). Current automated systems are slow and complex, prompting the need for a user-friendly robotic controller using gesture recognition.
    
3. **Research Objectives** – The study aims to: (1) recognize hand gestures for robotic arm control, (2) track hand movements accurately, and (3) develop a system to process and relay commands. A data glove with bending sensors and an OptiTrack motion-capture system were used for gesture and spatial tracking.
    
4. **Existing Solutions & Limitations** – Fully automated systems are slow and costly, IMU-based gloves suffer from drift errors, and OptiTrack systems struggle with obstructions. This research combines bending sensors and OptiTrack to improve accuracy and usability.
    
5. **Contributions** – The paper presents: (1) an integrated gesture-recognition system, (2) improved robotic control accuracy, and (3) a solution combining bending sensors and OptiTrack to overcome drift and tracking issues.
    
6. **Paper Structure** – The work compares different robotic control systems, evaluates gesture accuracy and response speed, and concludes with findings and future research direction
   
   ----
   
   ## 2 Related Works

7. **Fully Automated Systems**
    
    - Robots (e.g., Yoshida et al., Majeed et al.) aim to reduce labor but face issues like slow speeds, high costs, and limited adaptability to different crops/environments.
        
8. **Data Gloves with IMUs**
    
    - Enhance human-robot interaction with real-time hand tracking (Lu et al.).
        
    - Prone to drift errors and require complex calibration (Lin et al., Rodić et al.), reducing precision for delicate tasks like fruit harvesting.
        
9. **OptiTrack Systems**
    
    - Use high-precision cameras for better accuracy but struggle with **occlusion** (blocked line of sight), limiting effectiveness in outdoor farming.
        
10. **Comparison of Data Gloves**
    
    - Commercial gloves (HaptX, Manus Meta, TactGlove DK2) vary in cost and functionality.
        
    - Some rely on external VR cameras, while others integrate IMUs or bending sensors.
        
    - The proposed glove in this study is cost-effective (~$100) and suitable for mass production.
        
11. **Deep Learning in Gesture Recognition**
    
    - Recent advances (e.g., CNN, BiLSTM, attention mechanisms) improve accuracy in recognizing hand gestures.
        
    - Multi-modal systems (e.g., combining vision and bending sensors) enhance performance but increase computational costs.
        
12. **Human-Robot Interaction (HRI) Challenges**
    
    - Current systems lack ergonomic design, increasing cognitive load on operators.
        
    - Better feedback mechanisms and intuitive interfaces are needed (Rodić et al.).
        
13. **Proposed Hybrid Approach**
    
    - Combines **OptiTrack’s spatial accuracy** with **bending sensors** for robust gesture recognition in dynamic agricultural settings.
        
    - Aims to balance automation efficiency with human operator adaptability.

-----

## **3.1. Overview**

The system consists of three main components:

1. **Robotic Arm Controller** – Includes a **data glove** (with 10 bending sensors and 3 OptiTrack markers), **6 OptiTrack cameras**, and a **video monitor**.
    
2. **Server** – Runs three programs:
    
    - **Motive** (processes OptiTrack camera data into coordinates).
        
    - **Gesture recognition program** (decodes glove data and sends results).
        
    - **Data processing program** (sends control commands to the robotic arm).
        
3. **Robotic Arm** – A **myCobot 320 Pi** (6-DOF, Raspberry Pi-controlled) with a **Wi-Fi camera** for real-time feedback.
    

Data transmission is handled via **wired, wireless, and internal system communication**.

#### **3.2. Hardware Design**

##### **Data Glove**

- Contains **10 BS-65 bending sensors** (resistance changes with bending) and **3 OptiTrack reflective markers** for spatial tracking.
    
- Uses a **custom ESP32-S3 board** (with Wi-Fi, ADC, RTC, and battery management).
    
- **Circuit design**:
    
    - Inverting amplifier converts bending sensor resistance to voltage.
        
    - Optimal **feedback resistor (Rfb = 110 kΩ)** chosen via PSpice simulation for best sensitivity.
        

##### **Robotic Arm**

- **myCobot 320 Pi** (6-DOF, 1 kg payload, 320 mm reach).
    
- End effector (gripper) adds an extra degree of freedom.
    

#### **3.3. Software Design**

- **Four parallel programs** reduce latency:
    
    1. **ESP32 board program (C#)** – Reads bending sensor data.
        
    2. **Deep learning program (Python)** – Runs gesture recognition.
        
    3. **Data processing program (C)** – Translates gestures into robotic arm commands.
        
    4. **Robotic arm program** – Executes motor movements.
        

#### **3.4. Proportional Error Correction**

- **Linear regression** adjusts robotic arm coordinates to match human hand movements, correcting systematic delays.
    
- Equations:
    
    xm=kx⋅xh+bxym=ky⋅yh+byzm=kz⋅zh+bzxm​=kx​⋅xh​+bx​ym​=ky​⋅yh​+by​zm​=kz​⋅zh​+bz​
    
    (where xm,ym,zmxm​,ym​,zm​ = robotic arm positions; xh,yh,zhxh​,yh​,zh​ = hand positions).
    

#### **3.5. Deep Learning Models for Gesture Recognition**

Three models were tested:

1. **LSTM** – Good for sequential data (hand movement tracking).
    
2. **BiLSTM** – Improves recognition by analyzing sequences bidirectionally.
    
3. **CNN + BiLSTM** – Best performance:
    
    - **1D CNN** extracts spatial features from sensor data.
        
    - **Batch normalization & Leaky ReLU** improve learning stability.
        
    - **BiLSTM layers** capture temporal patterns for accurate gesture classification.
        
    - **Risk**: Higher complexity increases overfitting potential.

------  

## **4.1. Experiment 1: Spatial Trajectory Error**  
**Objective**: Measure the robotic arm’s ability to accurately follow human hand movements.  

**Method**:  
- Collected **1800 frames of data** (1 min per axis: X, Y, Z).  
- Adjusted displacement ratio to **1:1** (hand-to-robot movement).  
- Placed an **OptiTrack marker on the end-effector** for trajectory comparison.  

**Error Metrics**:  
1. **Mean Euclidean Distance**: **0.0131 m** (average deviation).  
2. **Standard Deviation**: **0.0100 m** (consistency of tracking).  
3. **Root Mean Square Error (RMSE)**: **0.0095 m** (overall accuracy).  

**Delay Correction**:  
- **Mean delay**: **0.325 s** (hand-to-robot response time).  
- **Standard deviation**: **0.0625 s** (low variability).  
- **Interquartile Range (IQR)**: **0.09 s** (middle 50% delays between 0.275 s and 0.365 s).  

**Result**:  
- High precision in replicating hand movements (**sub-centimeter accuracy**).  
- Systematic errors were effectively minimized (**Figure 11**).  


#### **4.2. Experiment 2: Hand Gesture Recognition Accuracy**  
**Objective**: Evaluate deep learning models for classifying **7 hand gestures**:  
1. Rest  
2. Show 1 (index finger up)  
3. Show 2 (index + middle fingers up)  
4. Claw  
5. Fist  
6. Pinch (index + thumb)  
7. All-finger pinch  

**Dataset**:  
- **100 samples per gesture** (10 repetitions × 10 conditions).  
- **1400 seconds total data**, sampled at **100 Hz**.  
- Split into **training (60%), validation (20%), testing (20%)**.  

**Models Compared**:  

| Model       | Accuracy | Precision | Recall | F1-Score | Parameters |  
|-------------|----------|-----------|--------|----------|------------|  
| CNN+BiLSTM  | **96.43%** | 96.69%    | 96.43% | 96.42%   | 365,511    |  
| BiLSTM      | 88.57%   | 89.08%    | 88.57% | 88.21%   | 80,071     |  
| LSTM        | 69.29%   | 72.29%    | 69.29% | 68.78%   | 19,655     |  

**Key Findings**:  
- **CNN+BiLSTM outperformed** others, leveraging:  
  - **CNN**: Spatial feature extraction (finger bending patterns).  
  - **BiLSTM**: Temporal sequence analysis (gesture dynamics).  
- **100% accuracy** for gestures 0 (rest), 4 (fist), 5 (pinch), 6 (all-finger pinch).  
- Minor confusion (~4–6% errors) between similar gestures (e.g., *show 1* vs. *show 2*).  
- Training curves (**Figure 14**) show **no overfitting**, with validation accuracy matching training.  

**Confusion Matrix (CNN+BiLSTM)**:  
- Darker blue = higher recognition rate.  
- Most errors occurred in **gestures 1–3** due to finger position similarities.  



### **Key Takeaways**  
1. **Precision in Motion Tracking**:  
   - Robotic arm achieves **sub-centimeter accuracy** in replicating hand trajectories.  
   - Delay correction ensures **stable synchronization** (~0.325 s latency).  

2. **Superior Gesture Recognition**:  
   - **CNN+BiLSTM** is optimal (96.4% accuracy) for real-time gesture control.  
   - Simpler models (BiLSTM, LSTM) trade accuracy for lower computational cost.  

3. **Real-World Applicability**:  
   - System reliably distinguishes **fine-grained gestures** (e.g., pinch vs. fist).  
   - Minimal misclassifications in dynamic agricultural environments.  
----

# 5 conclusion

1. **Hybrid System Advantages:** The integration of bending sensors and OptiTrack systems successfully addresses limitations of both fully automated systems (inflexibility) and traditional data gloves (occlusion issues), achieving sub-centimeter precision (mean error: 0.0131m) in robotic arm control.
    
2. **Gesture Recognition Performance:** The CNN+BiLSTM model achieved superior performance (96.4% accuracy) by effectively combining spatial feature extraction with temporal sequence analysis, outperforming standalone LSTM (69.3%) and BiLSTM (88.6%) models.
    
3. **Practical Implementation:** The system demonstrates:
    
    - High precision for delicate harvesting tasks
        
    - Good balance between accuracy and computational efficiency
        
    - Improved ergonomics to reduce operator cognitive load
        

**Future Directions:**

1. **System Robustness:**
    
    - Integrate IMUs with OptiTrack for occlusion resilience
        
    - Add environmental sensors (temperature/humidity) for real-time calibration
        
    - Implement multi-sensor fusion for challenging conditions
        
2. **Performance Enhancement:**
    
    - Explore advanced ML architectures (e.g., transformers)
        
    - Optimize for edge computing deployment
        
3. **Real-World Validation:**
    
    - Conduct field trials in diverse agricultural settings
        
    - Address practical challenges like variable lighting and obstructions
        
4. **Ergonomic Improvements:**
    
    - Reduce device weight/power consumption
        
    - Incorporate haptic feedback